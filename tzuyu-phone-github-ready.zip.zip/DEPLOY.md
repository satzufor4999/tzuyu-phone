# 发布到 GitHub Pages

1. 在 GitHub 创建公开仓库 `tzuyu-phone`。
2. 上传此文件夹**内部**的 `index.html`、`assets/`、`.nojekyll` 等文件到仓库根目录；不要再嵌套一层文件夹。
3. Repository Settings > Pages > Source: Deploy from a branch > Branch: main, /(root) > Save。
4. 站点地址一般为 https://用户名.github.io/tzuyu-phone/ 。

注意：静态站点内容公开可访问，包括模拟解锁密码和游戏素材。密码 0614 只起游戏模拟作用，没有真实保密能力。
